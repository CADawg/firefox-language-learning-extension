browser.runtime.onInstalled.addListener(() => {
    console.log('Extension installed');
    
    browser.storage.local.set({
        extensionData: {
            installDate: new Date().toISOString(),
            version: '1.0'
        }
    });
});

browser.browserAction.onClicked.addListener((tab) => {
    console.log('Extension icon clicked for tab:', tab.id);
});

browser.tabs.onActivated.addListener((activeInfo) => {
    console.log('Tab activated:', activeInfo.tabId);
});

browser.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
    if (changeInfo.status === 'complete' && tab.url) {
        console.log('Tab updated:', tab.url);
    }
});

browser.runtime.onMessage.addListener((request, sender, sendResponse) => {
    console.log('Message received in background:', request);
    
    if (request.action === 'backgroundAction') {
        sendResponse({success: true, message: 'Background action completed'});
    }
    
    return true;
});