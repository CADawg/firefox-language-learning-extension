console.log('Content script loaded');

browser.runtime.onMessage.addListener((request, sender, sendResponse) => {
    console.log('Message received in content script:', request);
    
    if (request.action === 'performAction') {
        const result = performPageAction();
        sendResponse({success: true, result: result});
    }
    
    return true;
});

function performPageAction() {
    const pageTitle = document.title;
    const pageUrl = window.location.href;
    
    console.log('Performing action on page:', pageTitle);
    
    const notification = document.createElement('div');
    notification.style.cssText = `
        position: fixed;
        top: 20px;
        right: 20px;
        background: #4CAF50;
        color: white;
        padding: 15px;
        border-radius: 5px;
        z-index: 10000;
        font-family: Arial, sans-serif;
        box-shadow: 0 2px 10px rgba(0,0,0,0.3);
    `;
    notification.textContent = 'Extension action performed!';
    
    document.body.appendChild(notification);
    
    setTimeout(() => {
        if (notification.parentNode) {
            notification.parentNode.removeChild(notification);
        }
    }, 3000);
    
    return {
        title: pageTitle,
        url: pageUrl,
        timestamp: new Date().toISOString()
    };
}

function highlightText(text) {
    const walker = document.createTreeWalker(
        document.body,
        NodeFilter.SHOW_TEXT,
        null,
        false
    );
    
    const textNodes = [];
    let node;
    
    while (node = walker.nextNode()) {
        if (node.nodeValue.includes(text)) {
            textNodes.push(node);
        }
    }
    
    textNodes.forEach(textNode => {
        const parent = textNode.parentNode;
        const wrapper = document.createElement('span');
        wrapper.style.backgroundColor = 'yellow';
        wrapper.style.padding = '2px';
        
        const content = textNode.nodeValue.replace(
            new RegExp(text, 'gi'),
            `<mark style="background-color: yellow; padding: 2px;">$&</mark>`
        );
        
        wrapper.innerHTML = content;
        parent.replaceChild(wrapper, textNode);
    });
}