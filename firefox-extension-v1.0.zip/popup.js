document.addEventListener('DOMContentLoaded', function() {
    const actionBtn = document.getElementById('actionBtn');
    const getTabInfoBtn = document.getElementById('getTabInfo');
    const statusDiv = document.getElementById('status');
    
    function showStatus(message, isError = false) {
        statusDiv.textContent = message;
        statusDiv.className = isError ? 'error' : 'success';
        statusDiv.style.display = 'block';
        
        setTimeout(() => {
            statusDiv.style.display = 'none';
        }, 3000);
    }
    
    actionBtn.addEventListener('click', function() {
        browser.tabs.query({active: true, currentWindow: true}).then(tabs => {
            browser.tabs.sendMessage(tabs[0].id, {
                action: 'performAction'
            }).then(response => {
                showStatus('Action performed successfully!');
            }).catch(error => {
                showStatus('Error performing action: ' + error.message, true);
            });
        });
    });
    
    getTabInfoBtn.addEventListener('click', function() {
        browser.tabs.query({active: true, currentWindow: true}).then(tabs => {
            const tab = tabs[0];
            showStatus(`Tab: ${tab.title} (${tab.url})`);
        }).catch(error => {
            showStatus('Error getting tab info: ' + error.message, true);
        });
    });
    
    browser.storage.local.get(['extensionData']).then(result => {
        if (result.extensionData) {
            console.log('Loaded extension data:', result.extensionData);
        }
    });
});